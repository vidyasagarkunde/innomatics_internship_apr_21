#!/usr/bin/env python
# coding: utf-8

# In[2]:


#question 1
#polor coordinates
import cmath

r = complex(input().strip())

print(cmath.polar(r)[0])
print(cmath.polar(r)[1])


# In[4]:


#question2
#angle MBC
import math
AB=int(input())

BC=int(input())
       
hype=math.hypot(AB,BC)                  
res=round(math.degrees(math.acos(BC/hype))) 
degree=chr(176)                             
print(res,degree, sep='')


# In[5]:


#question3
#triangle quest2

for i in range(1,int(input())+1):
    print(((10**i-1)//9)**2)
               


# In[7]:


#question4
#mod divmod

a=int(input())
b=int(input())
print(a//b)
print(a%b)
print(divmod(a,b))


# In[9]:


#question5
#power-mod power
a=int(input())
b=int(input())
m=int(input())

print(pow(a,b))
print(pow(a,b,m))


# In[10]:


#question6
#integers in all sizes

a=int(input())
b=int(input())
c=int(input())
d=int(input())
print((a**b)+(c**d))


# In[11]:


#question7
#triangle quest

for i in range(1,int(input())):
    print(int(i * 10**i / 9))

