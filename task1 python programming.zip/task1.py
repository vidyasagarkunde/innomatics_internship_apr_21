#!/usr/bin/env python
# coding: utf-8

# # task1:python programming

# In[1]:


#question 1
print("Hello,World!")


# In[2]:


#question2
#python if-else
import math
import os
import random
import re
import sys



if __name__ == '__main__':
    n = int(input().strip())
if(n%2!=0) or (n>=6 and n<=20):
    print("Weird ")
else:
    print("Not Weird")


# In[3]:


#question 3
#arthametic operations
if __name__ == '__main__':    
    a = int(input())
    b = int(input())
    print(a+b)
    print(a-b)
    print(a*b)


# In[4]:


#question 4
#division
if __name__ == '__main__':
    a = int(input())
    b = int(input())
    print(a//b)
    print(a/b)


# In[5]:


#question 5
#loop
if __name__ == '__main__':
    n = int(input())
    for i in range(0,n):
        print(i*i)


# In[6]:


#question 6
#print function
if __name__ == '__main__':
    n = int(input())
    for i in range(1,n+1):
        print(i,end="")


# In[ ]:




